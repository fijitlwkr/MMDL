# 검토 시작

[검토 안내](packets/gate18/README.md)를 먼저 읽는다. 배치 문서와 빈 labels.jsonl은 `packets/gate18/` 안에 있다. 이미지 폴더의 위치를 바꾸지 않는다.
